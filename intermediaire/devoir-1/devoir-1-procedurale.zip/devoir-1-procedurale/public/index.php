<?php
require '../fonctions/header.php';
?>
    <h1 class="text-center">Recherche d'informations : </h1>
    <p class="text-center py-3">
        Si vous recherchez des informations sur une ville, alors n'hésitez pas à utiliser
        notre formulaire de recherche. <br>
        Pour accéder à notre formulaire de recherche, vous devez vous connecter. <br>
        <a href="login.php" class="btn btn-primary my-3">Connexion</a>
    </p>
<?php
require '../fonctions/footer.php';
?>