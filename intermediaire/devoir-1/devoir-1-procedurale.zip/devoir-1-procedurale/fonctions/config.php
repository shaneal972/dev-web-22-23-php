<?php

    $host = 'localhost';
    $dbname = 'php_intermediaire_1';
    $user = 'inter';
    $password = 'devoir1';